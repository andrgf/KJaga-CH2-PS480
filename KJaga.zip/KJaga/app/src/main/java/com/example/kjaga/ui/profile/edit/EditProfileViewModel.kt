package com.example.kjaga.ui.profile.edit

import androidx.lifecycle.ViewModel

class EditProfileViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}