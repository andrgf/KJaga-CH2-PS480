package com.example.kjaga.data.requestBody

data class DiaryMeals(
    val foodId: Int?,
    val portionId: Int?,
    val quantity:Int
)
